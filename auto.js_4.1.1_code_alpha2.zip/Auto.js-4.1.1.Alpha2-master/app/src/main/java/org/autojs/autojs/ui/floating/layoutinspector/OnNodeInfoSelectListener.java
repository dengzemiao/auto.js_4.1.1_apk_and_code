package org.autojs.autojs.ui.floating.layoutinspector;

import com.stardust.view.accessibility.NodeInfo;

/**
 * Created by Stardust on 2017/3/10.
 */

public interface OnNodeInfoSelectListener {
    void onNodeSelect(NodeInfo info);

}
