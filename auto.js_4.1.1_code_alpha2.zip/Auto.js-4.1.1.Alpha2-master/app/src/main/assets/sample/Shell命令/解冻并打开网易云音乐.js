shell("pm enable com.netease.cloudmusic", true);
launchApp("网易云音乐");