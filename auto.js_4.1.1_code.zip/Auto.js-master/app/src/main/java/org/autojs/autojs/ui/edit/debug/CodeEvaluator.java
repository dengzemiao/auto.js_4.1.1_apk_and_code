package org.autojs.autojs.ui.edit.debug;

public interface CodeEvaluator {
    String eval(String code);
}
